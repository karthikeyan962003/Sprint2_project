package com.dhanusri.UserModule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
